/**
 * A homemade ArrayList class that simulates the built in ArrayList java class, using Arrays instead.
 *
 * Alex Lai
 * January 27, 2020
 */
public class ArrayList {
    private Object[] arr = new Object[2];
    private int numElements = 0;

    /**
     * Adds an object to the specified index... if there is already an object at that spot it will shift right.
     *
     * @param o     Object intended to be put in the ArrayList
     * @param index where they intend to put the object.
     */
    public void insert(Object o, int index) {
        if(index > numElements+1)
            throw new RuntimeException("You can't insert at that index.");

        if (arr.length == numElements)
            expand();
        if(arr[index] == null) {
            arr[index] = o;
            numElements++;
        }
        else {
            shift(index, 'r');
            arr[index] = o;
            numElements++;
        }


    }

    /**
     * Removes the object at the specified index. Resizes the array after it is removed.
     *
     * @param index The intended index of the object which will be removed
     * @return the Object removed.
     */
    public Object remove(int index) {
        if ((numElements - 1) == 0) {
            numElements--;
            return arr[index];
        }
        Object retVal = arr[index];
        shift(index, 'l');
        numElements--;
        return retVal;
    }


    /**
     * Returns the size of the ArrayList
     *
     * @return the ArrayList size
     */
    public int size() {
        return numElements;
    }

    /**
     * Overrided toString method.
     *
     * @return A string that contains the objects from the array.
     */
    @Override
    public String toString() {
        String str = "";
        for (int i = 0; i < numElements; i++)
                str += arr[i] + "  ";
        return str;
    }

    /**
     * Checks if the ArrayList is empty.
     *
     * @return whether or not the ArrayList is empty.
     */
    public boolean isEmpty() {
        if ((numElements == 0) || (arr[0] == null))
            return true;
        else
            return false;
    }

    /**
     * Checks if an ArrayList is equal to another ArrayList by going through every index.
     *
     * @param other
     * @return
     */
    public boolean equals(Object other) {
        if ((other == null) || !(other instanceof ArrayList)) //Checks if the other object is an ArrayList
            return false;

        ArrayList that = (ArrayList) other;
        if (this.size() != that.size()) //Checks if both ArrayLists are the same.
            return false;

        for (int i = 0; i < this.size(); i++) {
            if (this.get(i).equals(that.get(i)))
                continue;
            else
                return false;
        }
        return true;
    }

    /**
     * Returns the index of an Object of the specified index.
     *
     * @param o
     * @return the index of the object, returns -1 if not found
     */
    public int getIndexOf(Object o) {
        for (int i = 0; i < numElements; i++) {
            if (arr[i].equals(o))
                return i;
        }
        return -1;
    }

    /**
     * Get returns the object of a specified index in the ArrayList
     *
     * @param index requested index to get from the ArrayList
     * @return the object of the index in the ArrayList
     */
    public Object get(int index) {
        return arr[index];
    }


    /**
     * Shifts the array right or left.
     *
     * @param index Index where new object is in place.
     * @param c     'l' to shift left, 'r' to shift right.
     */
    public void shift(int index, char c) {
        if (c == 'r') {
            for (int i = numElements; i > index; i--)
                arr[i] = arr[i - 1];
        }
        if (c == 'l') {
            for (int j = index; j < numElements - 1; j++)
                arr[j] = arr[j + 1];
        }
    }




    /**
     * Expand or "Resize" will double the size of the array if it runs out of space.
     */
    private void expand() {
        Object[] box = new Object[arr.length * 2]; //Double the size of Old Array.
        for (int i = 0; i < numElements; i++)
            box[i] = arr[i];

        arr = box;
    }
}


