import java.io.*;

/**
 * The date class that represents the date in our world.
 * <p>
 * Alex Lai
 * February 3, 2020
 */
public class Date {
    private int month;
    private int day;
    private int year;

    /**
     * Sets the month, day, and year respectively. dateChecker checks if its inbounds.
     *
     * @param month has to be between 1 and 12.
     * @param day   has to be between 1 and 31.
     * @param year  has to be between 2016 and 2026.
     */
    public Date(int month, int day, int year) {
        this.month = month;
        this.day = day;
        this.year = year;
        dateChecker();
    }

    /**
     * Copy constructor for the Date class.
     *
     * @param other another Date object.
     */
    public Date(Date other) {
        this.month = other.month;
        this.day = other.day;
        this.year = other.year;
    }

    /**
     * Gets the year of the Date class.
     *
     * @return year of the Date class.
     */
    public int getYear() {
        return year;
    }

    /**
     * Gets the month of the Date class.
     *
     * @return month of the Date class.
     */
    public int getMonth() {
        return month;
    }

    /**
     * Gets the day of the Date class.
     *
     * @return day of the Date class.
     */
    public int getDay() {
        return day;
    }

    /**
     * Sets the year for this Date class. dateChecker will check if its between 2016 and 2026.
     *
     * @param year has to be between 2016 and 2026.
     */
    public void setYear(int year) {
        this.year = year;
        dateChecker();
    }

    /**
     * Sets the month for this Date class. dateChecker will check if its between 1 and 12.
     *
     * @param month has to be between 1 and 12.
     */
    public void setMonth(int month) {
        this.month = month;
        dateChecker();
    }

    /**
     * Sets the day for this Date class. dateChecker will check if its between 1 and 31.
     *
     * @param day has to be between 1 and 31.
     */
    public void setDay(int day) {
        this.day = day;
        dateChecker();
    }

    /**
     * This method checks whether or not another date is after this date.
     *
     * @param compareTo another date.
     * @return if the other date is after this date.
     */
    public boolean isAfter(Date compareTo) {
        int thisDays = day + (month * 31) + (year * 365);
        int otherDays = compareTo.day + (compareTo.month * 31) + (compareTo.year * 365);
        if (otherDays > thisDays)
            return true;
        else
            return false;
    }

    /**
     * Checks if another Date object equals this one.
     *
     * @param o another object.
     * @return whether or not the other date is the same as this one.
     */
    public boolean equals(Object o) {
        if ((o == null) || !(o instanceof Date))
            return false;

        Date that = (Date) o;
        return this.year == that.year && this.month == that.month && this.day == that.day;


    }

    /**
     * Prints out the date in proper String format "mm/dd/yyyy"
     *
     * @return the Date as a string
     */
    @Override
    public String toString() {
        String str = "";
        if (month < 10)
            str += "0" + month + "/";
        else
            str += month + "/";
        if (day < 10)
            str += "0" + day + "/";
        else
            str += day + "/";

        return str + year;

    }

    /**
     * Makes sure our month, days, and year is in check according to the assignment instructions.
     * Throws a Runtime Exception if it is out of bounds.
     */
    private void dateChecker() {
        if (month < 1 || month > 12)
            throw new RuntimeException("Month is not between 1 or 12.");
        if (day < 1 || day > 31)
            throw new RuntimeException("Day is not between 1 or 31.");
        if (year < 2016 || year > 2026)
            throw new RuntimeException("Year is not between 2016 or 2026");
    }
}
