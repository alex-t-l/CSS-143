/**
 * Simple driver to test Money, Date, and Bill classes
 * <p>
 * Alex Lai
 * February 3, 2020
 */
public class BillMoneyDateDriver {

    /**
     * Tests Money, Date, and Bill Objects.
     *
     * @param args
     */
    public static void main(String[] args) {
        //moneyTests();
        //dateTests();
        billTests();

    }

    /**
     * Test out the Money class.
     */
    public static void moneyTests() {
        Money goldIngot = new Money(9499, 99);
        Money nineGoldNuggets = new Money(goldIngot);
        System.out.println(goldIngot.equals(nineGoldNuggets));
        Money diamondSword = new Money(19999, 199); //Should be 20000 dollars.
        diamondSword.add(10000);
        System.out.println(diamondSword);
        //diamondSword.setMoney(-1,-1); //Should print a message: You can't have negative money.
        Money dirtBlock = new Money(0, 101);
        System.out.println(dirtBlock);
        System.out.println(diamondSword.getMoney());
    }

    /**
     * Test out the Date class.
     */
    public static void dateTests() {
        Date date1 = new Date(3, 20, 2020);
        Date date2 = new Date(12, 25, 2026);
        Date sameAsDate1 = new Date(date1);
        System.out.println(date1.isAfter(date2)); //IS DATE 2 AFTER DATE 1?
        System.out.println(date1.equals(date2));
        System.out.println(date1.equals(sameAsDate1));
        System.out.println(date1.toString());
        //date1.setYear(2027); //Throws an Runtime exception
        //date2.setMonth(13); //Throws a Runtime exception.
        date1.setDay(5);
        date1.setMonth(2);
        System.out.println(date1.toString());
    }

    /**
     * Test out the Bill class.
     */
    public static void billTests() {
        //My driver.
        Money noMoney = new Money(0, 1);
        Money UW_Tuition = new Money(40000);
        Date collegeDue = new Date(12, 31, 2026);
        Date collegePay = new Date(11, 25, 2026);
        Bill tuition = new Bill(UW_Tuition, collegeDue, "University of Washington");
        Bill sameBill = new Bill(tuition);
        System.out.println(tuition.equals(sameBill)); //should be the same.
        System.out.println(tuition);
        System.out.println(collegeDue.equals(tuition.getDueDate()));
        System.out.println(collegeDue == tuition.getDueDate()); //Privacy leak test. Wink wink ;)
        tuition.setPaid(collegePay); //Let's assumed I paid my tuition.
        System.out.println(tuition); //Now it should say I paid my tuition.
        System.out.println(tuition.setAmount(noMoney)); //Should not run since its already paid, and return false
        sameBill.setOriginator("Washington State University");
        Money newAmount = new Money(44000, 100000); //45000 dollars... WOW.
        sameBill.setAmount(newAmount);
        System.out.println(sameBill);
        Date wsu = new Date(12, 31, 2026);
        sameBill.setDueDate(wsu);
        System.out.println(sameBill);
        sameBill.setPaid(collegePay);
        System.out.println(sameBill); //Should be paid now.
        System.out.println(sameBill.isPaid());
        System.out.println(sameBill.setDueDate(collegeDue)); //Should return false since our bill is already paid.

        /**It seems like I've tested all the methods and they seem to be working. Privacy leaks also shouldn't be a problem
         since copy constructors were used everytime an objected was setted, getted, or copied.
         */

    }
}
