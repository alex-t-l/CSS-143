/**
 * The Bill object that represents a outstanding or paid bill.
 * <p>
 * Alex Lai
 * February 3, 2020
 */
public class Bill {
    private Money amount; //Amount due.
    private Date dueDate; //When the bill is due.
    private Date paidDate; //null if bill is not paid.
    private String originator; //Company or payer's name

    /**
     * Sets the values, paidDate is set to null since its not paid yet.
     *
     * @param amount     Money due.
     * @param dueDate    Bill due date.
     * @param originator Name of payer.
     */
    public Bill(Money amount, Date dueDate, String originator) {
        this.amount = new Money(amount);
        this.dueDate = new Date(dueDate);
        this.paidDate = null;
        this.originator = originator;
    }

    /**
     * Copy constructor for bill object.
     *
     * @param toCopy another Bill object.
     */
    public Bill(Bill toCopy) {
        this.amount = toCopy.getAmount();
        this.dueDate = toCopy.getDueDate();
        originator = toCopy.getOriginator();
    }

    /**
     * Returns the Money object amount.
     *
     * @return amount in a money object.
     */
    public Money getAmount() {
        return new Money(amount);
    }

    /**
     * Returns the Date object for the due date.
     *
     * @return the due date.
     */
    public Date getDueDate() {
        return new Date(dueDate);
    }

    /**
     * Returns the originator
     *
     * @return originator.
     */
    public String getOriginator() {
        return originator;
    }

    /**
     * Returns whether or not the bill is paid.
     *
     * @return true or false.
     */
    public boolean isPaid() {
        return (paidDate != null);
    }

    /**
     * Sets the paid date.
     *
     * @param if the date paid is after the due date, it will return false, else, paidDate is set to datePaid.
     * @return if it was paid on time.
     */
    public boolean setPaid(Date datePaid) {
        if (dueDate.isAfter(datePaid)) {
            return false;
        } else {
            paidDate = new Date(datePaid);
            return true;
        }
    }

    /**
     * Sets a new due date.
     *
     * @param nextDate next date object.
     * @return whether or not the new due date was set. Will only set if the bill wasn't paid.
     */
    public boolean setDueDate(Date nextDate) {
        if (isPaid()) {
            return false;
        } else {
            dueDate = new Date(nextDate);
            return true;
        }
    }

    /**
     * Changes the price of the bill.
     *
     * @param amount the new bill.
     * @return whether or not the bill was changed.
     */
    public boolean setAmount(Money amount) {
        if (isPaid()) {
            return false;
        } else {
            this.amount = new Money(amount);
            return true;
        }
    }

    /**
     * Changes the payer's name.
     *
     * @param originator New payer's name.
     */
    public void setOriginator(String originator) {
        this.originator = originator;
    }

    /**
     * Prints out all the elements of the bill.
     *
     * @return The bill in String format.
     */
    @Override
    public String toString() {
        String paid = "";
        if (isPaid())
            paid += "Status: Bill paid on " + paidDate.toString();
        else
            paid += "Status: Bill not paid.";

        return "Amount: " + amount + " Due Date: " + dueDate + " Originator: " + originator + " " + paid;
    }

    /**
     * Checks if a bill is identical to another bill.
     *
     * @param toCompare a bill to compare to.
     * @return whether or not the bill equals the other bill.
     */
    public boolean equals(Object toCompare) {
        if ((toCompare == null) || !(toCompare instanceof Bill))
            return false;
        Bill that = (Bill) toCompare;
        return this.amount.equals(that.amount) && this.dueDate.equals(that.dueDate) && this.isPaid()==(that.isPaid()) && this.originator.equals(that.originator);

    }
}

