/**
 * This is the Money class which represents dollars and cents.
 * <p>
 * Alex Lai
 * February 2, 2020
 */
public class Money {
    private int dollars = 0; //Dollars can't be negative.
    private int cents = 0; //Cents can't be higher than 99, or negative.

    /**
     * To take in dollars.
     *
     * @param dol dollar amount.
     */
    public Money(int dol) {
        dollars = dol;
        cents = 0;
        moneyChecker();
    }

    /**
     * Takes in amount of dollars or cents.
     *
     * @param dol  dollar amount.
     * @param cent cents amount.
     */
    public Money(int dol, int cent) {
        dollars = dol;
        cents = cent;
        moneyChecker();
    }

    /**
     * Copy constructor for Money
     *
     * @param other the other Money object.
     */
    public Money(Money other) {
        this.dollars = other.dollars;
        this.cents = other.cents;
        moneyChecker();
    }

    /**
     * Returns dollars.
     *
     * @return dollars.
     */
    public int getDollars() {
        return dollars;
    }

    /**
     * Returns cents.
     *
     * @return cents.
     */
    public int getCents() {
        return cents;
    }

    /**
     * Method that sets your dollars and cents. You can put in 100 cents to represent a dollar.
     *
     * @param dollars dollars value.
     * @param cents   cents value.
     */
    public void setMoney(int dollars, int cents) {
        this.dollars = dollars;
        this.cents = cents;
        moneyChecker();
    }


    /**
     * Gets the Money value as a double.
     *
     * @return Money value.
     */
    public double getMoney() {
        return Double.parseDouble(dollars +"."+cents);
    }

    /**
     * Add dollars to total money.
     *
     * @param dollars added to dollars.
     */
    public void add(int dollars) {
        this.dollars += dollars;
    }

    /**
     * Adds dollars and cents to money. You can put 100 cents to represent a dollar.
     *
     * @param dollars added to dollars.
     * @param cents   added to cents.
     */
    public void add(int dollars, int cents) {
        this.dollars += dollars;
        this.cents += cents;
        moneyChecker();
    }

    /**
     * Adds money from another Money object.
     *
     * @param other another Money object.
     */
    public void add(Money other) {
        dollars += other.dollars;
        cents += other.cents;
        moneyChecker();
    }

    /**
     * Checks if two Money objects are the same amount.
     *
     * @param o another Object.
     * @return Whether or not they equal.
     */
    @Override
    public boolean equals(Object o) {
        if ((o == null) || !(o instanceof Money))
            return false;
        Money that = (Money) o;
        return this.dollars == that.dollars && this.cents == that.cents;
    }

    /**
     * This method checks if cents is over 99 cents and fixes that, and notifies the use if you have negative money (which you shouldn't)
     */
    private void moneyChecker() {
        if (this.cents > 99) {
            this.dollars += this.cents / 100;
            int change = this.cents % 100;
            this.cents = change;
        }
        if (this.dollars < 0 || this.cents < 0) {
            System.out.println("You can't have negative money.");
        }
    }

    /**
     * Prints the amount of money.
     *
     * @return how much money in dollars and cents.
     */
    public String toString() {
        if (cents < 10)
            return "$" + dollars + ".0" + cents;
        else
            return "$" + dollars + "." + cents;

    }
}

