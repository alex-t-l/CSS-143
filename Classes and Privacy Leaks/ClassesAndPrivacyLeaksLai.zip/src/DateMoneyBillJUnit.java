/**
 * JUNIT Tests for Privacy Leaks Assignment.
 * Alex Lai
 * February 3, 2020
 */
/*
 * JUnit tests for Date, Money, and Bill classes
 * @author Lesley Kalmin
 *  CSS162
 */

import static org.junit.Assert.*;

import org.junit.Test;

public class DateMoneyBillJUnit {
    //From here is the skeleton code.
    @Test
    public void ConstructMoneyTest() {
        Money money1 = new Money(10);

        assertEquals(10, money1.getDollars());
    }

    @Test
    public void SetMoneyTest() {
        Money money1 = new Money(10, 99);

        money1.setMoney(30, 50);
        assertEquals(30, money1.getDollars());
        assertEquals(50, money1.getCents());
    }

    @Test
    public void ConstructMoneyCopyTest() {
        Money money1 = new Money(99, 99);
        money1.setMoney(10, 40);

        Money money2 = new Money(money1);

        assertEquals(10, money1.getDollars());
        assertEquals(40, money2.getCents());
    }

    @Test
    public void PrintMoneyTest() {
        Money money1 = new Money(10);

        money1.setMoney(30, 50);
        assertEquals("$30.50", money1.toString());

    }

    //From here I made these tests.

	/**
	 * A privacy leak test- mainly checking if the memory addresses are different, which they should be.
	 */
    @Test
    public void privacyLeakTest() {
        Money theMoney = new Money(19, 99);
        Date theDateDue = new Date(12, 25, 2020);
        Date theDatePaid = new Date(12, 24, 2020);
        Bill xmasBill = new Bill(theMoney, theDateDue, "Mary's Little Lambs");
        Bill xmasBill2 = new Bill(xmasBill);
        assertEquals(false, xmasBill == xmasBill2); //Because it should be different memory spots.
        assertEquals(true, xmasBill.equals(xmasBill2)); //Should be same variable/object values
    }

	/**
	 * Some JUnit Money tests.
	 */
	@Test
	public void moneyTests(){
		Money goldIngot = new Money(9499, 100);
		Money nineGoldNuggets = new Money(goldIngot);
		assertEquals(true, goldIngot.equals(nineGoldNuggets));
		assertEquals(false, goldIngot == nineGoldNuggets);
		assertEquals("$9500.00", goldIngot.toString());

	}

	/**
	 * Some JUnit Date tests.
	 */
	@Test
	public void dateTests(){
		Date date1 = new Date(3, 20, 2020);
		Date date2 = new Date(12, 25, 2026);
		Date sameAsDate1 = new Date(date1);
		assertEquals(true, date1.equals(sameAsDate1));
		assertEquals("12/25/2026", date2.toString());
		assertEquals(2020, date1.getYear());

	}
}
